from pathlib import Path
import os
import sqlite3
from typing import Generator

#BASE_DIR = Path(__file__).resolve().parent.parent
#DB_PATH = Path(os.getenv("DB_PATH", BASE_DIR / "administradora.db"))
#SQL_DIR = BASE_DIR / "db"

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

DB_PATH = Path(os.getenv("DB_PATH", DATA_DIR / "administradora.db"))
SQL_DIR = DATA_DIR
print(BASE_DIR)
print(DB_PATH)
print(SQL_DIR)

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db() -> Generator[sqlite3.Connection, None, None]:
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


def run_migrations() -> None:
    if not DB_PATH.exists():
        raise FileNotFoundError(f"No se encontró la base de datos: {DB_PATH}")
    with get_connection() as conn:
        for sql_file in sorted(SQL_DIR.glob("*.sql")):
            conn.executescript(sql_file.read_text(encoding="utf-8"))
        conn.commit()


if __name__ == "__main__":
    run_migrations()
    print(f"Migraciones aplicadas en {DB_PATH}")
