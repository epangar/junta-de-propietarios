from fastapi import APIRouter, Depends, HTTPException, status
from sqlite3 import Connection, IntegrityError

from app.database import get_db
from app.schemas.usuario_schema import UsuarioCreate, UsuarioResponse
from app.services.security import admin_required, hash_password

router = APIRouter(prefix="/usuarios", tags=["Usuarios"])


@router.post("", response_model=UsuarioResponse, status_code=status.HTTP_201_CREATED)
def crear_usuario(
    payload: UsuarioCreate,
    db: Connection = Depends(get_db),
    current_user: dict = Depends(admin_required),
):
    """
    Crea un usuario nuevo.

    Requiere autenticación con Bearer Token y rol `admin`.
    """
    try:
        cursor = db.execute(
            """
            INSERT INTO Usuario (username, email, password, rol, activo)
            VALUES (?, ?, ?, ?, 1)
            """,
            (
                payload.username,
                payload.email,
                hash_password(payload.password),
                payload.rol,
            ),
        )
        db.commit()

        usuario = db.execute(
            """
            SELECT id_usuario, username, email, rol, fecha_creacion, fecha_modificacion, activo
            FROM Usuario
            WHERE id_usuario = ?
            """,
            (cursor.lastrowid,),
        ).fetchone()

        if usuario is None:
            raise HTTPException(status_code=500, detail="No se pudo recuperar el usuario creado")

        return dict(usuario)

    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Ya existe un usuario con ese username o email",
        ) from exc
