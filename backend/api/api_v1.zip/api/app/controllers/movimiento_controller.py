from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlite3 import Connection
from app.database import get_db
from app.models import movimiento_model as model
from app.schemas.movimiento_schema import MovimientoCreate, MovimientoUpdate, MovimientoResponse, TipoMovimiento

router = APIRouter(prefix="/movimientos", tags=["Movimientos"])


@router.get("", response_model=list[MovimientoResponse])
def listar_movimientos(
    anio: int | None = Query(default=None, ge=2000, le=2100),
    tipo: TipoMovimiento | None = Query(default=None),
    db: Connection = Depends(get_db),
):
    return model.get_all(db, anio=anio, tipo=tipo.value if tipo else None)


@router.get("/{id}", response_model=MovimientoResponse)
def detalle_movimiento(id: int, db: Connection = Depends(get_db)):
    mov = model.get_by_id(db, id)
    if not mov:
        raise HTTPException(status_code=404, detail="Movimiento no encontrado")
    return mov


@router.post("", response_model=MovimientoResponse, status_code=status.HTTP_201_CREATED)
def crear_movimiento(payload: MovimientoCreate, db: Connection = Depends(get_db)):
    return model.create(db, payload.model_dump())


@router.put("/{id}", response_model=MovimientoResponse)
def actualizar_movimiento(id: int, payload: MovimientoUpdate, db: Connection = Depends(get_db)):
    if not model.get_by_id(db, id):
        raise HTTPException(status_code=404, detail="Movimiento no encontrado")
    return model.update(db, id, payload.model_dump())


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_movimiento(id: int, db: Connection = Depends(get_db)):
    if not model.get_by_id(db, id):
        raise HTTPException(status_code=404, detail="Movimiento no encontrado")
    model.delete(db, id)
    return None
