from fastapi import APIRouter, Depends, HTTPException, status
from sqlite3 import Connection
from app.database import get_db
from app.models import apartamento_model as model
from app.schemas.apartamento_schema import (
    ApartamentoCreate, ApartamentoUpdate, ApartamentoDeudaPatch,
    ApartamentoResponse, MorosoPagoRequest, MorosoTotalResponse,
)

router = APIRouter(tags=["Apartamentos"])


@router.get("/apartamentos", response_model=list[ApartamentoResponse])
def listar_apartamentos(db: Connection = Depends(get_db)):
    return model.get_all(db)


@router.get("/apartamentos/{id}", response_model=ApartamentoResponse)
def detalle_apartamento(id: int, db: Connection = Depends(get_db)):
    apto = model.get_by_id(db, id)
    if not apto:
        raise HTTPException(status_code=404, detail="Apartamento no encontrado")
    return apto


@router.post("/apartamentos", response_model=ApartamentoResponse, status_code=status.HTTP_201_CREATED)
def crear_apartamento(payload: ApartamentoCreate, db: Connection = Depends(get_db)):
    return model.create(db, payload.model_dump())


@router.put("/apartamentos/{id}", response_model=ApartamentoResponse)
def actualizar_apartamento(id: int, payload: ApartamentoUpdate, db: Connection = Depends(get_db)):
    if not model.get_by_id(db, id):
        raise HTTPException(status_code=404, detail="Apartamento no encontrado")
    return model.update(db, id, payload.model_dump())


@router.patch("/apartamentos/{id}/deuda", response_model=ApartamentoResponse)
def actualizar_deuda(id: int, payload: ApartamentoDeudaPatch, db: Connection = Depends(get_db)):
    if not model.get_by_id(db, id):
        raise HTTPException(status_code=404, detail="Apartamento no encontrado")
    return model.update_deuda(db, id, payload.deuda)


@router.delete("/apartamentos/{id}", status_code=status.HTTP_204_NO_CONTENT)
def eliminar_apartamento(id: int, db: Connection = Depends(get_db)):
    if not model.get_by_id(db, id):
        raise HTTPException(status_code=404, detail="Apartamento no encontrado")
    model.delete(db, id)
    return None


@router.get("/morosos", response_model=list[ApartamentoResponse])
def listar_morosos(db: Connection = Depends(get_db)):
    return model.get_morosos(db)


@router.get("/morosos/total", response_model=MorosoTotalResponse)
def total_morosos(db: Connection = Depends(get_db)):
    return {"total_deuda": model.get_total_deuda(db)}


@router.post("/morosos/pago", response_model=ApartamentoResponse)
def registrar_pago_moroso(payload: MorosoPagoRequest, db: Connection = Depends(get_db)):
    apto = model.registrar_pago(db, payload.id_apto, payload.monto, payload.concepto)
    if not apto:
        raise HTTPException(status_code=404, detail="Apartamento no encontrado")
    return apto
