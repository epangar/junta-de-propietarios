from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlite3 import Connection
from app.database import get_db
from app.schemas.auth_schema import LoginRequest, LoginResponse, LogoutResponse
from app.services.security import create_token, ensure_session_table, verify_password

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, db: Connection = Depends(get_db)):
    ensure_session_table(db)
    user = db.execute(
        "SELECT id_usuario, username, email, password, rol FROM Usuario WHERE username=? AND activo=1",
        (payload.username,),
    ).fetchone()
    if user is None or not verify_password(payload.password, user["password"]):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Credenciales inválidas")

    token = create_token()
    db.execute("INSERT INTO Sesion(token, id_usuario) VALUES (?, ?)", (token, user["id_usuario"]))
    db.commit()
    return {
        "access_token": token,
        "user": {
            "id_usuario": user["id_usuario"],
            "username": user["username"],
            "email": user["email"],
            "rol": user["rol"],
        },
    }


@router.post("/logout", response_model=LogoutResponse)
def logout(authorization: str | None = Header(default=None), db: Connection = Depends(get_db)):
    ensure_session_table(db)
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token no enviado")
    token = authorization.split(" ", 1)[1]
    db.execute("DELETE FROM Sesion WHERE token=?", (token,))
    db.commit()
    return {"message": "Sesión cerrada correctamente"}
