from sqlite3 import Connection


def row_to_dict(row):
    return dict(row) if row else None


def get_all(db: Connection, anio: int | None = None, tipo: str | None = None):
    query = "SELECT * FROM Movimiento_contable WHERE 1=1"
    params = []
    if anio is not None:
        query += " AND strftime('%Y', fecha) = ?"
        params.append(str(anio))
    if tipo is not None:
        query += " AND tipo = ?"
        params.append(tipo)
    query += " ORDER BY fecha DESC, id_movimiento DESC"
    return [dict(r) for r in db.execute(query, params).fetchall()]


def get_by_id(db: Connection, id_movimiento: int):
    return row_to_dict(db.execute("SELECT * FROM Movimiento_contable WHERE id_movimiento=?", (id_movimiento,)).fetchone())


def create(db: Connection, data: dict):
    cur = db.execute(
        """
        INSERT INTO Movimiento_contable (id_edificio, id_apto, tipo, concepto, monto, fecha, descripcion)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (data.get("id_edificio"), data.get("id_apto"), data["tipo"], data["concepto"], data["monto"], str(data["fecha"]), data.get("descripcion")),
    )
    db.commit()
    return get_by_id(db, cur.lastrowid)


def update(db: Connection, id_movimiento: int, data: dict):
    db.execute(
        """
        UPDATE Movimiento_contable
        SET id_edificio=?, id_apto=?, tipo=?, concepto=?, monto=?, fecha=?, descripcion=?
        WHERE id_movimiento=?
        """,
        (data.get("id_edificio"), data.get("id_apto"), data["tipo"], data["concepto"], data["monto"], str(data["fecha"]), data.get("descripcion"), id_movimiento),
    )
    db.commit()
    return get_by_id(db, id_movimiento)


def delete(db: Connection, id_movimiento: int):
    db.execute("DELETE FROM Movimiento_contable WHERE id_movimiento=?", (id_movimiento,))
    db.commit()
