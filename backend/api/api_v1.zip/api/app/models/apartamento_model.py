from sqlite3 import Connection


def row_to_dict(row):
    return dict(row) if row else None


def calcular_estado(deuda: float) -> str:
    return "Moroso" if deuda and deuda > 0 else "Al día"


def get_all(db: Connection):
    rows = db.execute("SELECT * FROM Apartamento ORDER BY id_apto").fetchall()
    return [dict(r) for r in rows]


def get_by_id(db: Connection, id_apto: int):
    return row_to_dict(db.execute("SELECT * FROM Apartamento WHERE id_apto = ?", (id_apto,)).fetchone())


def create(db: Connection, data: dict):
    estado = calcular_estado(data["deuda"])
    cur = db.execute(
        """
        INSERT INTO Apartamento
        (id_edificio, cuota_mes, derrama, deuda, estado, propietario, telefono, email, id_usuario)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data.get("id_edificio"), data["cuota_mes"], data.get("derrama", 0), data.get("deuda", 0),
            estado, data["propietario"], data.get("telefono"), data.get("email"), data.get("id_usuario")
        ),
    )
    db.commit()
    return get_by_id(db, cur.lastrowid)


def update(db: Connection, id_apto: int, data: dict):
    estado = calcular_estado(data["deuda"])
    db.execute(
        """
        UPDATE Apartamento
        SET id_edificio=?, cuota_mes=?, derrama=?, deuda=?, estado=?, propietario=?, telefono=?, email=?, id_usuario=?
        WHERE id_apto=?
        """,
        (
            data.get("id_edificio"), data["cuota_mes"], data.get("derrama", 0), data["deuda"], estado,
            data["propietario"], data.get("telefono"), data.get("email"), data.get("id_usuario"), id_apto
        ),
    )
    db.commit()
    return get_by_id(db, id_apto)


def update_deuda(db: Connection, id_apto: int, deuda: float):
    estado = calcular_estado(deuda)
    db.execute("UPDATE Apartamento SET deuda=?, estado=? WHERE id_apto=?", (deuda, estado, id_apto))
    db.commit()
    return get_by_id(db, id_apto)


def delete(db: Connection, id_apto: int):
    db.execute("DELETE FROM Apartamento WHERE id_apto=?", (id_apto,))
    db.commit()


def get_morosos(db: Connection):
    rows = db.execute("SELECT * FROM Apartamento WHERE deuda > 0 ORDER BY deuda DESC").fetchall()
    return [dict(r) for r in rows]


def get_total_deuda(db: Connection):
    row = db.execute("SELECT COALESCE(SUM(deuda), 0) AS total_deuda FROM Apartamento WHERE deuda > 0").fetchone()
    return float(row["total_deuda"])


def registrar_pago(db: Connection, id_apto: int, monto: float, concepto: str):
    apto = get_by_id(db, id_apto)
    if not apto:
        return None
    nueva_deuda = max(float(apto["deuda"] or 0) - monto, 0)
    actualizado = update_deuda(db, id_apto, nueva_deuda)
    db.execute(
        """
        INSERT INTO Movimiento_contable (id_edificio, id_apto, tipo, concepto, monto, fecha, descripcion)
        VALUES (?, ?, 'Ingreso', ?, ?, DATE('now'), ?)
        """,
        (apto.get("id_edificio"), id_apto, concepto, monto, f"Pago aplicado. Deuda restante: {nueva_deuda}"),
    )
    db.commit()
    return actualizado
