from datetime import datetime
from typing import Optional, Literal
from pydantic import BaseModel, EmailStr, Field


class UsuarioCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50, examples=["nuevo_usuario"])
    email: EmailStr = Field(..., examples=["usuario@email.com"])
    password: str = Field(..., min_length=6, max_length=128, examples=["usuario123"])
    rol: Literal["admin", "junta", "propietario"] = Field(..., examples=["propietario"])


class UsuarioResponse(BaseModel):
    id_usuario: int
    username: str
    email: EmailStr
    rol: str
    fecha_creacion: Optional[datetime] = None
    fecha_modificacion: Optional[datetime] = None
    activo: int
