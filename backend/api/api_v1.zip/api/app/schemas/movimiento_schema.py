from datetime import date
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field


class TipoMovimiento(str, Enum):
    ingreso = "Ingreso"
    gasto = "Gasto"


class MovimientoBase(BaseModel):
    id_edificio: Optional[int] = None
    id_apto: Optional[int] = None
    tipo: TipoMovimiento
    concepto: str = Field(..., min_length=3)
    monto: float = Field(..., ge=0)
    fecha: date
    descripcion: Optional[str] = None


class MovimientoCreate(MovimientoBase):
    pass


class MovimientoUpdate(MovimientoBase):
    pass


class MovimientoResponse(MovimientoBase):
    id_movimiento: int
