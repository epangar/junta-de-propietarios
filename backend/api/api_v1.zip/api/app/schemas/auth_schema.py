from pydantic import BaseModel, EmailStr, Field


class LoginRequest(BaseModel):
    username: str = Field(..., min_length=3, examples=["admin_principal"])
    password: str = Field(..., min_length=1, examples=["admin123"])


class UserResponse(BaseModel):
    id_usuario: int
    username: str
    email: EmailStr
    rol: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


class LogoutResponse(BaseModel):
    message: str
