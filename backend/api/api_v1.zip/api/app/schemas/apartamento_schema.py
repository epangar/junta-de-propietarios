from pydantic import BaseModel, EmailStr, Field, computed_field
from typing import Optional


class ApartamentoBase(BaseModel):
    id_edificio: Optional[int] = None
    cuota_mes: float = Field(..., ge=0)
    derrama: float = Field(0, ge=0)
    deuda: float = Field(0, ge=0)
    propietario: str = Field(..., min_length=2)
    telefono: Optional[str] = None
    email: Optional[EmailStr] = None
    id_usuario: Optional[int] = None


class ApartamentoCreate(ApartamentoBase):
    pass


class ApartamentoUpdate(ApartamentoBase):
    pass


class ApartamentoDeudaPatch(BaseModel):
    deuda: float = Field(..., ge=0)


class ApartamentoResponse(ApartamentoBase):
    id_apto: int
    estado: str


class MorosoPagoRequest(BaseModel):
    id_apto: int = Field(..., gt=0)
    monto: float = Field(..., gt=0)
    concepto: str = Field("Pago deuda moroso", min_length=3)


class MorosoTotalResponse(BaseModel):
    total_deuda: float
