import hashlib
import hmac
import secrets
from fastapi import Depends, Header, HTTPException, status
from sqlite3 import Connection
from app.database import get_db


def verify_password(plain_password: str, stored_password: str) -> bool:
    """
    Soporta contraseñas guardadas como:
    - texto plano, solo para desarrollo
    - salt$sha256(salt + password), habitual en ejercicios con SQLite
    """
    if "$" not in stored_password:
        return hmac.compare_digest(plain_password, stored_password)

    salt, expected_hash = stored_password.split("$", 1)
    calculated = hashlib.sha256((salt + plain_password).encode("utf-8")).hexdigest()
    return hmac.compare_digest(calculated, expected_hash)



def hash_password(plain_password: str) -> str:
    """
    Genera un hash compatible con verify_password: salt$sha256(salt + password).
    """
    salt = secrets.token_hex(16)
    password_hash = hashlib.sha256((salt + plain_password).encode("utf-8")).hexdigest()
    return f"{salt}${password_hash}"


def create_token() -> str:
    return secrets.token_urlsafe(32)


def ensure_session_table(db: Connection) -> None:
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS Sesion (
            token TEXT PRIMARY KEY,
            id_usuario INTEGER NOT NULL,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario)
        )
        """
    )
    db.commit()


def get_current_user(
    authorization: str | None = Header(default=None),
    db: Connection = Depends(get_db),
):
    ensure_session_table(db)
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token no enviado")

    token = authorization.split(" ", 1)[1]
    row = db.execute(
        """
        SELECT u.id_usuario, u.username, u.email, u.rol
        FROM Sesion s
        JOIN Usuario u ON u.id_usuario = s.id_usuario
        WHERE s.token = ? AND u.activo = 1
        """,
        (token,),
    ).fetchone()
    if row is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido")
    return dict(row)
def require_role(required_role: str):
    def dependency(current_user: dict = Depends(get_current_user)):
        if current_user.get("rol") != required_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="No tienes permisos para realizar esta acción",
            )
        return current_user

    return dependency


admin_required = require_role("admin")

