# API Junta de Condominios - FastAPI + SQLite

## Instalación
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

Copia `administradora.db` en la raíz del proyecto o configura:
```bash
export DB_PATH=/ruta/administradora.db
```

Ejecuta migraciones:
```bash
python -m app.database
```

Arranca la API:
```bash
uvicorn app.main:app --reload
```

Docs: http://127.0.0.1:8000/docs
