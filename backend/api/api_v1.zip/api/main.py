from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import run_migrations
from app.controllers.auth_controller import router as auth_router
from app.controllers.apartamento_controller import router as apartamento_router
from app.controllers.movimiento_controller import router as movimiento_router

app = FastAPI(
    title="API Junta de Condominios",
    version="1.0.0",
    description="API MVC con FastAPI, SQLite y Pydantic para gestión de apartamentos, morosos y movimientos contables.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200", "http://127.0.0.1:4200"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    run_migrations()


@app.get("/")
def healthcheck():
    return {"status": "ok", "message": "API Junta de Condominios activa"}


app.include_router(auth_router)
app.include_router(apartamento_router)
app.include_router(movimiento_router)
